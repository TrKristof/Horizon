using HorizonAdminApp.Models;
using HorizonAdminApp.Services;

namespace HorizonAdminApp.Views.EditPages;

public partial class EditStudentPopup : ContentPage
{
    private readonly DatabaseService _dbService;
    private readonly Action _refreshCallback;

    public EditStudentPopup(Student student, DatabaseService dbService, Action refreshCallback)
    {
        InitializeComponent();
        BindingContext = student;
        _dbService = dbService;
        _refreshCallback = refreshCallback;
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        var student = BindingContext as Student;
        if (student != null)
        {
            await _dbService.UpdateStudent(student);
            _refreshCallback?.Invoke();
            await Navigation.PopModalAsync();
        }
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopModalAsync();
    }
}