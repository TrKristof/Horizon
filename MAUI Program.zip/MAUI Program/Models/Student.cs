﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorizonAdminApp.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public int? StudentCard {  get; set; }
        public int SchoolId { get; set; }
        public DateTime Date { get; set; }
        public DateTime ExpirationDate { get; set; }
    }
}
