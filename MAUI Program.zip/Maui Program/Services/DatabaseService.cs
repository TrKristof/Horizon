﻿using HorizonAdminApp.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorizonAdminApp.Services
{
    public class DatabaseService
    {
        private readonly string connectionString = "Server=localhost;Database=horizon;Uid=root;Pwd=;";

        public async Task<bool> ValidateAdmin(string username, string password)
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("SELECT COUNT(*) FROM admins WHERE Name=@username AND Password=@password", conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                int count = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                return count > 0;
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült belépni: {ex.Message}", "OK"));
                return false;
            }
        }

        public async Task<List<School>> GetSchools()
        {
            var schools = new List<School>();
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("SELECT Id, Name, Address FROM schools", conn);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    schools.Add(new School
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Address = reader.IsDBNull(2) ? "" : reader.GetString(2)
                    });
                }
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült betölteni az iskolákat: {ex.Message}", "OK"));
            }
            return schools;
        }

        public async Task<List<Student>> GetStudentsBySchool(int schoolId)
        {
            var students = new List<Student>();
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("SELECT Id, Name, Email, StudentCard, Date, ExpirationDate FROM students WHERE SchoolId=@schoolId", conn);
                cmd.Parameters.AddWithValue("@schoolId", schoolId);

                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    students.Add(new Student
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Email = reader.IsDBNull(2) ? "" : reader.GetString(2),
                        StudentCard = reader.IsDBNull(3) ? (int?)null : reader.GetInt32(3),
                        SchoolId = schoolId,
                        Date = reader.GetDateTime(4),
                        ExpirationDate = reader.GetDateTime(5)
                    });
                }
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült betölteni a diákokat: {ex.Message}", "OK"));
            }
            return students;
        }

        public async Task<List<Teacher>> GetTeachersBySchool(int schoolId)
        {
            var teachers = new List<Teacher>();
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("SELECT Id, Name, Email, IdentityCard, Date, ExpirationDate FROM teachers WHERE SchoolId=@schoolId", conn);
                cmd.Parameters.AddWithValue("@schoolId", schoolId);

                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    teachers.Add(new Teacher
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Email = reader.IsDBNull(2) ? "" : reader.GetString(2),
                        IdentityCard = reader.IsDBNull(3) ? (int?)null : reader.GetInt32(3),
                        SchoolId = schoolId,
                        Date = reader.GetDateTime(4),
                        ExpirationDate = reader.GetDateTime(5)
                    });
                }
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült betölteni a tanárokat: {ex.Message}", "OK"));
            }
            return teachers;
        }

        public async Task UpdateStudent(Student student)
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("UPDATE students SET Name=@name, Email=@email, StudentCard=@studentCard WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@name", student.Name);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@studentCard", student.StudentCard ?? (int?)null);
                cmd.Parameters.AddWithValue("@id", student.Id);

                await cmd.ExecuteNonQueryAsync();
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Siker", "A diák adatai frissítve lettek!", "OK"));
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült frissíteni a diákot: {ex.Message}", "OK"));
            }
        }

        public async Task DeleteStudent(int id)
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("DELETE FROM students WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);

                await cmd.ExecuteNonQueryAsync();
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Siker", "A diák törölve lett!", "OK"));
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült törölni a diákot: {ex.Message}", "OK"));
            }
        }

        public async Task UpdateTeacher(Teacher teacher)
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("UPDATE teachers SET Name=@name, Email=@email, IdentityCard=@identityCard WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@name", teacher.Name);
                cmd.Parameters.AddWithValue("@email", teacher.Email);
                cmd.Parameters.AddWithValue("@identityCard", teacher.IdentityCard ?? (int?)null);
                cmd.Parameters.AddWithValue("@id", teacher.Id);

                await cmd.ExecuteNonQueryAsync();
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Siker", "A tanár adatai frissítve lettek!", "OK"));
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült frissíteni a tanárt: {ex.Message}", "OK"));
            }
        }

        public async Task DeleteTeacher(int id)
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                await conn.OpenAsync();
                var cmd = new MySqlCommand("DELETE FROM teachers WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);

                await cmd.ExecuteNonQueryAsync();
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Siker", "A tanár törölve lett!", "OK"));
            }
            catch (Exception ex)
            {
                await MainThread.InvokeOnMainThreadAsync(() =>
                    App.Current?.MainPage?.DisplayAlert("Hiba", $"Nem sikerült törölni a tanárt: {ex.Message}", "OK"));
            }
        }
    }
}
