using HorizonAdminApp.Models;
using HorizonAdminApp.Services;

namespace HorizonAdminApp.Views.EditPages;

public partial class EditTeacherPopup : ContentPage
{
    private readonly DatabaseService _dbService;
    private readonly Action _refreshCallback;

    public EditTeacherPopup(Teacher teacher, DatabaseService dbService, Action refreshCallback)
    {
        InitializeComponent();
        BindingContext = teacher;
        _dbService = dbService;
        _refreshCallback = refreshCallback;
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        var teacher = BindingContext as Teacher;
        if (teacher != null)
        {
            await _dbService.UpdateTeacher(teacher);
            _refreshCallback?.Invoke();
            await Navigation.PopModalAsync();
        }
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopModalAsync();
    }
}