﻿using HorizonAdminApp.Models;
using HorizonAdminApp.Services;
using System.Collections.ObjectModel;

namespace HorizonAdminApp.Views.EditPages;

public partial class SchoolDetailsPage : ContentPage
{
    private readonly DatabaseService _dbService = new();
    public School School { get; set; }
    public ObservableCollection<Student> Students { get; set; } = new();
    public ObservableCollection<Teacher> Teachers { get; set; } = new();

    public SchoolDetailsPage(School school)
    {
        InitializeComponent();
        School = school;
        BindingContext = this;
        LoadData();
    }

    private async void LoadData()
    {
        var students = await _dbService.GetStudentsBySchool(School.Id);
        Students.Clear();
        foreach (var s in students)
            Students.Add(s);

        var teachers = await _dbService.GetTeachersBySchool(School.Id);
        Teachers.Clear();
        foreach (var t in teachers)
            Teachers.Add(t);
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnEditStudent(object sender, EventArgs e)
    {
        var student = (sender as Button)?.BindingContext as Student;
        if (student != null)
            await Navigation.PushModalAsync(new EditStudentPopup(student, _dbService, LoadData));
    }

    private async void OnDeleteStudent(object sender, EventArgs e)
    {
        var student = (sender as Button)?.BindingContext as Student;
        if (student != null && await DisplayAlert("Törlés", $"Biztosan törlöd {student.Name} diákot?", "Igen", "Nem"))
        {
            await _dbService.DeleteStudent(student.Id);
            LoadData();
        }
    }

    private async void OnEditTeacher(object sender, EventArgs e)
    {
        var teacher = (sender as Button)?.BindingContext as Teacher;
        if (teacher != null)
            await Navigation.PushModalAsync(new EditTeacherPopup(teacher, _dbService, LoadData));
    }

    private async void OnDeleteTeacher(object sender, EventArgs e)
    {
        var teacher = (sender as Button)?.BindingContext as Teacher;
        if (teacher != null && await DisplayAlert("Törlés", $"Biztosan törlöd {teacher.Name} tanárt?", "Igen", "Nem"))
        {
            await _dbService.DeleteTeacher(teacher.Id);
            LoadData();
        }
    }
}