using HorizonAdminApp.Models;
using HorizonAdminApp.Services;
using HorizonAdminApp.Views.EditPages;

namespace HorizonAdminApp.Views;

public partial class SchoolsPage : ContentPage
{
    private readonly DatabaseService _databaseService = new();
    private List<School> allSchools = new();

    public SchoolsPage()
    {
        InitializeComponent();
        LoadSchools();
    }

    private async void LoadSchools()
    {
        allSchools = await _databaseService.GetSchools();
        schoolsCollectionView.ItemsSource = allSchools;
    }

    private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        string filter = e.NewTextValue?.ToLower() ?? "";
        schoolsCollectionView.ItemsSource = allSchools
            .Where(s => s.Name?.ToLower().Contains(filter) ?? false)
            .ToList();
    }

    private async void OnSchoolSelected(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is School selectedSchool)
        {
            await Navigation.PushAsync(new SchoolDetailsPage(selectedSchool));
            schoolsCollectionView.SelectedItem = null;
        }
    }
}