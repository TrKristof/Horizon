﻿using HorizonAdminApp.Services;

namespace HorizonAdminApp.Views;

public partial class LoginPage : ContentPage
{
    private readonly DatabaseService _dbService = new();

    public LoginPage()
    {
        InitializeComponent();
    }

    private async void OnLoginClicked(object sender, EventArgs e)
    {
        string username = usernameEntry.Text?.Trim() ?? "";
        string password = passwordEntry.Text?.Trim() ?? "";

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
        {
            await DisplayAlert("Hiba", "Kérlek add meg a felhasználónevet és jelszót.", "OK");
            return;
        }

        bool success = await _dbService.ValidateAdmin(username, password);

        if (success)
        {
            await Navigation.PushAsync(new SchoolsPage());
        }
        else
        {
            await DisplayAlert("Hiba", "Hibás felhasználónév vagy jelszó.", "OK");
        }
    }
}